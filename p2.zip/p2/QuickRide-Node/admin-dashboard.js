class AdminDashboard {
    constructor() {
        this.init();
    }

    async init() {
        this.setCurrentDate();
        await this.loadDashboardStats();
        await this.loadRecentActivity();
        this.initializeCharts();
        this.setupEventListeners();
    }

    setCurrentDate() {
        const now = new Date();
        const el = document.getElementById('current-date');
        if (el) {
            el.textContent = now.toLocaleDateString('en-US', {
                weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'
            });
        }
    }

    async loadDashboardStats() {
        try {
            const response = await fetch('/api/dashboard/stats');
            const stats = await response.json();

            document.getElementById('total-bookings').textContent = stats.totalBookings || 0;
            document.getElementById('total-revenue').textContent = `$${stats.totalRevenue || 0}`;
            document.getElementById('available-cars').textContent = stats.availableCars || 0;
            document.getElementById('pending-bookings').textContent = stats.pendingBookings || 0;
        } catch (error) {
            console.error('Error loading dashboard stats:', error);
        }
    }

    async loadRecentActivity() {
        try {
            const response = await fetch('/api/bookings?limit=5');
            const bookings = await response.json();

            const activityHtml = bookings.map(booking => `
                <div class="mb-3">
                    <div class="fw-bold">${booking.full_name} booked ${booking.make} ${booking.model}</div>
                    <small class="text-muted">${new Date(booking.start_time).toLocaleDateString()} • ${booking.status}</small>
                </div>
            `).join('');

            const el = document.getElementById('recent-activity');
            if (el) el.innerHTML = activityHtml || '<div class="text-muted">No recent activity</div>';
        } catch (error) {
            console.error('Error loading recent activity:', error);
        }
    }

    initializeCharts() {
        try {
            const bookingEl = document.getElementById('bookingChart');
            if (bookingEl) {
                const bookingCtx = bookingEl.getContext('2d');
                this.bookingChart = new Chart(bookingCtx, {
                    type: 'line',
                    data: {
                        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                        datasets: [{ label: 'Bookings', data: [12, 19, 15, 25, 22, 30], borderColor: '#2b6ef6', tension: 0.1 }]
                    },
                    options: { responsive: true }
                });
            }

            const revenueEl = document.getElementById('revenueChart');
            if (revenueEl) {
                const revenueCtx = revenueEl.getContext('2d');
                this.revenueChart = new Chart(revenueCtx, {
                    type: 'bar',
                    data: { labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'], datasets: [{ label: 'Revenue ($)', data: [1200, 1900, 1500, 2500, 2200, 3000], backgroundColor: '#7b3afc' }] }
                });
            }
        } catch (err) {
            console.error('Chart init error:', err);
        }
    }

    setupEventListeners() {
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                const target = e.currentTarget.getAttribute('href').substring(1);
                this.handleTabChange(target);
            });
        });
    }

    async handleTabChange(tabName) {
        switch (tabName) {
            case 'bookings':
                await this.loadBookings();
                await this.loadCustomersForSelect();
                await this.loadCarsForSelect();
                break;
            case 'cars':
                await this.loadCars();
                break;
            case 'customers':
                await this.loadCustomers();
                break;
            case 'payments':
                await this.loadPayments();
                break;
        }
    }

    async loadBookings() {
        try {
            const response = await fetch('/api/bookings');
            const bookings = await response.json();
            const tbody = document.getElementById('bookingsTableBody');
            if (tbody) tbody.innerHTML = bookings.map(booking => `
                <tr>
                    <td>${booking.booking_id}</td>
                    <td>${booking.full_name}</td>
                    <td>${booking.make} ${booking.model}</td>
                    <td>${new Date(booking.start_time).toLocaleString()}</td>
                    <td>${new Date(booking.end_time).toLocaleString()}</td>
                    <td><span class="badge bg-${this.getStatusBadgeColor(booking.status)}">${booking.status}</span></td>
                    <td>
                        <button class="btn btn-sm btn-outline-primary" onclick="editBooking(${booking.booking_id})"><i class="fas fa-edit"></i></button>
                        <button class="btn btn-sm btn-outline-danger" onclick="deleteBooking(${booking.booking_id})"><i class="fas fa-trash"></i></button>
                    </td>
                </tr>
            `).join('');
        } catch (error) { console.error('Error loading bookings:', error); }
    }

    async loadCars() {
        try {
            const response = await fetch('/api/cars');
            const cars = await response.json();
            const tbody = document.getElementById('carsTableBody');
            if (tbody) tbody.innerHTML = cars.map(car => `
                <tr>
                    <td>${car.car_id}</td>
                    <td>${car.make}</td>
                    <td>${car.model}</td>
                    <td>${car.year || ''}</td>
                    <td>${car.license_plate || ''}</td>
                    <td>${car.category || ''}</td>
                    <td>${car.seats || ''}</td>
                    <td>${car.price_per_day != null ? '$' + Number(car.price_per_day).toFixed(2) : ''}</td>
                    <td><span class="badge bg-${this.getStatusBadgeColor(car.status)}">${car.status}</span></td>
                    <td>
                        <button class="btn btn-sm btn-outline-primary" onclick="editCar(${car.car_id})"><i class="fas fa-edit"></i></button>
                        <button class="btn btn-sm btn-outline-danger" onclick="deleteCar(${car.car_id})"><i class="fas fa-trash"></i></button>
                    </td>
                </tr>
            `).join('');
        } catch (error) { console.error('Error loading cars:', error); }
    }

    async loadCustomers() {
        try {
            const response = await fetch('/api/customers');
            const customers = await response.json();
            const tbody = document.getElementById('customersTableBody');
            if (tbody) tbody.innerHTML = customers.map(c => `
                <tr>
                    <td>${c.customer_id}</td>
                    <td>${c.full_name}</td>
                    <td>${c.email}</td>
                    <td>${c.phone_number || ''}</td>
                    <td>
                        <button class="btn btn-sm btn-outline-info" onclick="viewCustomer(${c.customer_id})"><i class="fas fa-eye"></i></button>
                        <button class="btn btn-sm btn-outline-danger" onclick="deleteCustomer(${c.customer_id})"><i class="fas fa-trash"></i></button>
                    </td>
                </tr>
            `).join('');
        } catch (error) { console.error('Error loading customers:', error); }
    }

    async loadCustomersForSelect() {
        try {
            const response = await fetch('/api/customers');
            const customers = await response.json();
            const select = document.getElementById('customerSelect');
            if (select) select.innerHTML = '<option value="">Select Customer</option>' + customers.map(c => `<option value="${c.customer_id}">${c.full_name} (${c.email})</option>`).join('');
        } catch (error) { console.error(error); }
    }

    async loadCarsForSelect() {
        try {
            const response = await fetch('/api/cars');
            const cars = await response.json();
            const select = document.getElementById('carSelect');
            if (select) select.innerHTML = '<option value="">Select Car</option>' + cars.filter(car => car.status === 'available').map(car => `<option value="${car.car_id}">${car.make} ${car.model} (${car.license_plate})</option>`).join('');
        } catch (error) { console.error(error); }
    }

    async loadPayments() {
        try {
            const response = await fetch('/api/payments');
            const payments = await response.json();
            const tbody = document.getElementById('paymentsTableBody');
            if (tbody) tbody.innerHTML = payments.map(p => `
                <tr>
                    <td>${p.payment_id}</td>
                    <td>${p.booking_id}</td>
                    <td>$${Number(p.amount).toFixed(2)}</td>
                    <td>${p.payment_method || ''}</td>
                    <td>${new Date(p.payment_date).toLocaleString()}</td>
                    <td>
                        <button class="btn btn-sm btn-outline-info" onclick="viewPayment(${p.payment_id})"><i class="fas fa-eye"></i></button>
                        <button class="btn btn-sm btn-outline-danger" onclick="deletePayment(${p.payment_id})"><i class="fas fa-trash"></i></button>
                    </td>
                </tr>
            `).join('');
        } catch (err) { console.error('Error loading payments:', err); }
    }

    getStatusBadgeColor(status) {
        const colors = { available: 'success', pending: 'warning', confirmed: 'primary', cancelled: 'danger', completed: 'info', maintenance: 'secondary', rented: 'dark' };
        return colors[status] || 'secondary';
    }
}

async function addCar() {
    const form = document.getElementById('addCarForm');
    const formData = new FormData(form);
    const carData = Object.fromEntries(formData);
    try {
        const response = await fetch('/api/cars', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(carData) });
        const result = await response.json();
        if (response.ok) { alert('Car added successfully!'); bootstrap.Modal.getInstance(document.getElementById('addCarModal')).hide(); form.reset(); adminDashboard.loadCars(); } else { alert('Error: ' + result.error); }
    } catch (error) { alert('Error adding car: ' + error.message); }
}

async function addBooking() {
    const form = document.getElementById('addBookingForm');
    const formData = new FormData(form);
    const bookingData = Object.fromEntries(formData);
    try {
        const response = await fetch('/api/bookings', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(bookingData) });
        const result = await response.json();
        if (response.ok) { alert('Booking added successfully!'); bootstrap.Modal.getInstance(document.getElementById('addBookingModal')).hide(); form.reset(); adminDashboard.loadBookings(); } else { alert('Error: ' + result.error); }
    } catch (error) { alert('Error adding booking: ' + error.message); }
}

// Delete a car by id (called from action button)
async function deleteCar(carId) {
    if (!confirm('Are you sure you want to delete this car? This action cannot be undone.')) return;
    try {
        const res = await fetch(`/api/cars/${carId}`, { method: 'DELETE' });
        const data = await res.json();
        if (res.ok) {
            alert('Car deleted');
            if (adminDashboard) adminDashboard.loadCars();
        } else {
            alert(data.error || 'Failed to delete car');
        }
    } catch (err) {
        console.error('Delete car error:', err);
        alert('Error deleting car: ' + err.message);
    }
}

// Edit a car: simple prompt-based editor that updates fields
async function editCar(carId) {
    try {
        const res = await fetch(`/api/cars/${carId}`);
        if (!res.ok) return alert('Failed to load car details');
        const car = await res.json();

        const make = prompt('Make', car.make);
        if (make === null) return; // cancelled
        const model = prompt('Model', car.model);
        if (model === null) return;
        const year = prompt('Year', car.year || '');
        if (year === null) return;
        const license_plate = prompt('License Plate', car.license_plate || '');
        if (license_plate === null) return;
        const status = prompt('Status (available, maintenance, rented)', car.status || 'available');
        if (status === null) return;
        const category = prompt('Category', car.category || '');
        if (category === null) return;
        const seats = prompt('Seats', car.seats || '');
        if (seats === null) return;
        const price_per_day = prompt('Price per day', car.price_per_day || '');
        if (price_per_day === null) return;
        const image = prompt('Image URL', car.image || '');
        if (image === null) return;

        const payload = { make, model, year, license_plate, status, category, seats: seats ? Number(seats) : null, price_per_day: price_per_day ? Number(price_per_day) : null, image };

        const updateRes = await fetch(`/api/cars/${carId}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
        const result = await updateRes.json();
        if (updateRes.ok) {
            alert('Car updated successfully');
            if (adminDashboard) adminDashboard.loadCars();
        } else {
            alert(result.error || 'Failed to update car');
        }
    } catch (err) {
        console.error('Edit car error:', err);
        alert('Error updating car: ' + err.message);
    }
}

// Booking edit/delete handlers
async function editBooking(bookingId) {
    try {
        const res = await fetch(`/api/bookings/${bookingId}`);
        if (!res.ok) return alert('Failed to load booking details');
        const b = await res.json();

        const start_time = prompt('Start Time (YYYY-MM-DDTHH:MM)', new Date(b.start_time).toISOString().slice(0, 16));
        if (start_time === null) return;
        const end_time = prompt('End Time (YYYY-MM-DDTHH:MM)', new Date(b.end_time).toISOString().slice(0, 16));
        if (end_time === null) return;
        const status = prompt('Status (pending, confirmed, cancelled, completed)', b.status || 'pending');
        if (status === null) return;

        const payload = { customer_id: b.customer_id, car_id: b.car_id, start_time, end_time, status };
        const updateRes = await fetch(`/api/bookings/${bookingId}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
        const result = await updateRes.json();
        if (updateRes.ok) { alert('Booking updated'); if (adminDashboard) adminDashboard.loadBookings(); }
        else alert(result.error || 'Failed to update booking');
    } catch (err) { console.error('Edit booking error:', err); alert('Error updating booking: ' + err.message); }
}

async function deleteBooking(bookingId) {
    if (!confirm('Delete this booking?')) return;
    try {
        const res = await fetch(`/api/bookings/${bookingId}`, { method: 'DELETE' });
        const data = await res.json();
        if (res.ok) { alert('Booking deleted'); if (adminDashboard) adminDashboard.loadBookings(); }
        else alert(data.error || 'Failed to delete booking');
    } catch (err) { console.error('Delete booking error:', err); alert('Error deleting booking: ' + err.message); }
}

// Customer handlers
async function viewCustomer(customerId) {
    try {
        const res = await fetch(`/api/customers/${customerId}`);
        if (!res.ok) return alert('Failed to load customer');
        const c = await res.json();
        alert(`Customer: ${c.full_name}\nEmail: ${c.email}\nPhone: ${c.phone_number || ''}`);
    } catch (err) { console.error('View customer error:', err); alert('Error loading customer: ' + err.message); }
}

async function deleteCustomer(customerId) {
    if (!confirm('Delete this customer? This will not remove bookings/payments automatically.')) return;
    try {
        const res = await fetch(`/api/customers/${customerId}`, { method: 'DELETE' });
        const data = await res.json();
        if (res.ok) { alert('Customer deleted'); if (adminDashboard) adminDashboard.loadCustomers(); }
        else alert(data.error || 'Failed to delete customer');
    } catch (err) { console.error('Delete customer error:', err); alert('Error deleting customer: ' + err.message); }
}

async function deletePayment(paymentId) {
    if (!confirm('Delete this payment?')) return;
    try {
        const res = await fetch(`/api/payments/${paymentId}`, { method: 'DELETE' });
        const data = await res.json();
        if (res.ok) {
            alert('Payment deleted');
            if (adminDashboard) adminDashboard.loadPayments();
        } else {
            alert(data.error || 'Failed to delete payment');
        }
    } catch (err) {
        console.error('Delete payment error:', err);
        alert('Error deleting payment: ' + err.message);
    }
}

function viewPayment(paymentId) {
    // Simple viewer: in a real app this would open a modal with details/receipt
    alert('Open payment details for ID: ' + paymentId);
}

function generateReport(type) { alert(`Generating ${type} report... This would download a PDF in a real application.`); }

let adminDashboard;
document.addEventListener('DOMContentLoaded', () => { adminDashboard = new AdminDashboard(); });
