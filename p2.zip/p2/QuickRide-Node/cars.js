(async () => {
    const tableBody = document.querySelector('table tbody');
    const paginationEl = document.querySelector('.pagination');
    const pageSize = 5;
    let cars = [];
    let currentPage = 1;

    function renderTable(page) {
        const start = (page - 1) * pageSize;
        const pageItems = cars.slice(start, start + pageSize);
        tableBody.innerHTML = pageItems.map(car => {
            const query = (car.make || '') + ' ' + (car.model || '') + ' car';
            const unsplash = `https://source.unsplash.com/600x400/?${encodeURIComponent(query)}`;
            const imgUrl = car.image && car.image.trim() ? car.image : unsplash;
            return `
            <tr>
                <td><img src="${imgUrl}" alt="${car.make || ''} ${car.model || ''}" style="height:60px; width:auto; border-radius:6px"></td>
                <td>${car.make || ''}</td>
                <td>${car.model || ''}</td>
                <td>${car.year || ''}</td>
                <td>${car.license_plate || ''}</td>
                <td>${car.seats || car.seating_capacity || ''}</td>
                <td>${car.price_per_day || car.price || ''}</td>
                <td>${car.status || ''}</td>
            </tr>
        `}).join('');
    }

    function renderPagination() {
        const totalPages = Math.max(1, Math.ceil(cars.length / pageSize));
        let html = '';
        html += `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}"><a class="page-link" href="#" data-page="prev">Previous</a></li>`;
        for (let i = 1; i <= totalPages; i++) {
            html += `<li class="page-item ${i === currentPage ? 'active' : ''}"><a class="page-link" href="#" data-page="${i}">${i}</a></li>`;
        }
        html += `<li class="page-item ${currentPage === totalPages ? 'disabled' : ''}"><a class="page-link" href="#" data-page="next">Next</a></li>`;
        paginationEl.innerHTML = html;

        paginationEl.querySelectorAll('a.page-link').forEach(a => {
            a.addEventListener('click', (e) => {
                e.preventDefault();
                const p = a.getAttribute('data-page');
                const total = Math.max(1, Math.ceil(cars.length / pageSize));
                if (p === 'prev' && currentPage > 1) currentPage--;
                else if (p === 'next' && currentPage < total) currentPage++;
                else if (!isNaN(parseInt(p))) currentPage = parseInt(p);
                renderTable(currentPage);
                renderPagination();
                tableBody.closest('section')?.scrollIntoView({ behavior: 'smooth' });
            });
        });
    }

    try {
        const res = await fetch('/api/cars');
        if (!res.ok) throw new Error('Failed to fetch cars: ' + res.status);
        cars = await res.json();
        if (!Array.isArray(cars)) cars = [];
    } catch (err) {
        console.error(err);
        cars = [];
    }

    if (cars.length === 0) {
        tableBody.innerHTML = '<tr><td colspan="8" class="text-center text-muted">No cars found</td></tr>';
    }

    renderTable(currentPage);
    renderPagination();
})();
