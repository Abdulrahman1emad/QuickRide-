const express = require('express');
const path = require('path');
const fs = require('fs');
const bodyParser = require('body-parser');
const cors = require('cors');
const db = require('./db');

const app = express();
app.use(cors());
app.use(bodyParser.json());

app.use(express.static(path.join(__dirname, '..')));

app.get('/api/dashboard/stats', (req, res) => {
    const stats = {};
    db.query('SELECT COUNT(*) as total FROM bookings', (err, results) => {
        if (err) return res.status(500).send(err);
        stats.totalBookings = results[0].total;

        db.query('SELECT SUM(amount) as revenue FROM payments', (err, results) => {
            if (err) return res.status(500).send(err);
            stats.totalRevenue = results[0].revenue || 0;

            db.query('SELECT COUNT(*) as available FROM cars WHERE status = "available"', (err, results) => {
                if (err) return res.status(500).send(err);
                stats.availableCars = results[0].available;

                db.query('SELECT COUNT(*) as pending FROM bookings WHERE status = "pending"', (err, results) => {
                    if (err) return res.status(500).send(err);
                    stats.pendingBookings = results[0].pending;

                    res.json(stats);
                });
            });
        });
    });
});

app.get('/api/bookings', (req, res) => {
    const sql = `
        SELECT b.*, c.full_name, c.email, car.make, car.model 
        FROM bookings b 
        JOIN customers c ON b.customer_id = c.customer_id 
        JOIN cars car ON b.car_id = car.car_id
        ORDER BY b.start_time DESC
    `;
    db.query(sql, (err, results) => {
        if (err) return res.status(500).send(err);
        res.json(results);
    });
});

app.get('/api/bookings/:id', (req, res) => {
    const id = req.params.id;
    const sql = `
        SELECT b.*, c.full_name, c.email, car.make, car.model 
        FROM bookings b 
        JOIN customers c ON b.customer_id = c.customer_id 
        JOIN cars car ON b.car_id = car.car_id
        WHERE b.booking_id = ?
    `;
    db.query(sql, [id], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        if (results.length === 0) return res.status(404).json({ error: 'Booking not found' });
        res.json(results[0]);
    });
});

app.put('/api/bookings/:id', (req, res) => {
    const id = req.params.id;
    const { customer_id, car_id, start_time, end_time, status } = req.body;
    const sql = `UPDATE bookings SET customer_id = ?, car_id = ?, start_time = ?, end_time = ?, status = ? WHERE booking_id = ?`;
    db.query(sql, [customer_id || null, car_id || null, start_time || null, end_time || null, status || null, id], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: 'Booking updated', affectedRows: result.affectedRows });
    });
});

app.delete('/api/bookings/:id', (req, res) => {
    const id = req.params.id;
    db.query('DELETE FROM bookings WHERE booking_id = ?', [id], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        if (result.affectedRows === 0) return res.status(404).json({ error: 'Booking not found' });
        db.query('DELETE FROM payments WHERE booking_id = ?', [id], (pErr) => { if (pErr) console.error('Failed to delete payments for booking', pErr); });
        res.json({ message: 'Booking deleted' });
    });
});

app.post('/api/bookings', (req, res) => {
    const { customer_id, car_id, start_time, end_time, status } = req.body;
    const sql = "INSERT INTO bookings (customer_id, car_id, start_time, end_time, status) VALUES (?, ?, ?, ?, ?)";

    db.query(sql, [customer_id, car_id, start_time, end_time, status], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });

        const amount = calculateBookingAmount(start_time, end_time, car_id);
        const paymentSql = "INSERT INTO payments (booking_id, amount, payment_method, payment_date) VALUES (?, ?, 'credit_card', NOW())";
        db.query(paymentSql, [result.insertId, amount], (err, paymentResult) => {
            if (err) console.error('Payment creation failed:', err);
        });

        res.json({ message: "Booking added successfully!", bookingId: result.insertId });
    });
});

app.get('/api/cars', (req, res) => {
    db.query('SELECT * FROM cars ORDER BY car_id DESC', (err, results) => {
        if (err) return res.status(500).send(err);
        res.json(results);
    });
});

app.post('/api/cars', (req, res) => {
    const { make, model, year, license_plate, status, category, seats, price_per_day, image } = req.body;
    const sql = "INSERT INTO cars (make, model, year, license_plate, status, category, seats, price_per_day, image) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

    db.query(sql, [make, model, year, license_plate, status, category || null, seats || null, price_per_day || null, image || null], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: "Car added successfully!", carId: result.insertId });
    });
});

app.get('/api/cars/:id', (req, res) => {
    const id = req.params.id;
    db.query('SELECT * FROM cars WHERE car_id = ?', [id], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        if (results.length === 0) return res.status(404).json({ error: 'Car not found' });
        res.json(results[0]);
    });
});

app.put('/api/cars/:id', (req, res) => {
    const id = req.params.id;
    const { make, model, year, license_plate, status, category, seats, price_per_day, image } = req.body;
    const sql = `UPDATE cars SET make = ?, model = ?, year = ?, license_plate = ?, status = ?, category = ?, seats = ?, price_per_day = ?, image = ? WHERE car_id = ?`;

    db.query(sql, [make, model, year, license_plate, status, category || null, seats || null, price_per_day || null, image || null, id], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: 'Car updated', affectedRows: result.affectedRows });
    });
});

app.delete('/api/cars/:id', (req, res) => {
    const id = req.params.id;
    db.query('DELETE FROM cars WHERE car_id = ?', [id], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        if (result.affectedRows === 0) return res.status(404).json({ error: 'Car not found' });
        res.json({ message: 'Car deleted' });
    });
});

app.get('/api/customers', (req, res) => {
    db.query('SELECT * FROM customers ORDER BY customer_id DESC', (err, results) => {
        if (err) return res.status(500).send(err);
        res.json(results);
    });
});

app.get('/api/customers/:id', (req, res) => {
    const id = req.params.id;
    db.query('SELECT * FROM customers WHERE customer_id = ?', [id], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        if (results.length === 0) return res.status(404).json({ error: 'Customer not found' });
        res.json(results[0]);
    });
});

app.delete('/api/customers/:id', (req, res) => {
    const id = req.params.id;
    db.query('DELETE FROM customers WHERE customer_id = ?', [id], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        if (result.affectedRows === 0) return res.status(404).json({ error: 'Customer not found' });
        res.json({ message: 'Customer deleted' });
    });
});

app.post('/api/customers', (req, res) => {
    const { full_name, email, phone_number } = req.body;
    if (!email || !full_name) return res.status(400).json({ error: 'full_name and email are required' });

    db.query('SELECT * FROM customers WHERE email = ?', [email], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        if (results.length > 0) {
            return res.json({ message: 'Customer exists', customer: results[0] });
        }

        const sql = 'INSERT INTO customers (full_name, email, phone_number) VALUES (?, ?, ?)';
        db.query(sql, [full_name, email, phone_number || null], (err, result) => {
            if (err) return res.status(500).json({ error: err.message });
            db.query('SELECT * FROM customers WHERE customer_id = ?', [result.insertId], (err2, rows) => {
                if (err2) return res.status(500).json({ error: err2.message });
                res.json({ message: 'Customer created', customer: rows[0] });
            });
        });
    });
});

app.get('/api/payments', (req, res) => {
    const sql = `
        SELECT p.*, b.booking_id, c.full_name 
        FROM payments p 
        JOIN bookings b ON p.booking_id = b.booking_id 
        JOIN customers c ON b.customer_id = c.customer_id
        ORDER BY p.payment_date DESC
    `;
    db.query(sql, (err, results) => {
        if (err) return res.status(500).send(err);
        res.json(results);
    });
});

app.get('/api/reports/monthly-revenue', (req, res) => {
    const sql = `
        SELECT 
            MONTH(payment_date) as month,
            SUM(amount) as revenue
        FROM payments 
        WHERE YEAR(payment_date) = YEAR(CURDATE())
        GROUP BY MONTH(payment_date)
        ORDER BY month
    `;
    db.query(sql, (err, results) => {
        if (err) return res.status(500).send(err);
        res.json(results);
    });
});

app.get('/api/images', (req, res) => {
    const imagesDir = path.join(__dirname, '..', 'images');
    fs.readdir(imagesDir, (err, files) => {
        if (err) return res.status(500).json({ error: err.message });
        const imageFiles = files.filter(f => /\.(jpe?g|png|gif|svg|avif|webp)$/i.test(f));
        res.json(imageFiles);
    });
});

app.delete('/api/payments/:id', (req, res) => {
    const id = req.params.id;
    db.query('DELETE FROM payments WHERE payment_id = ?', [id], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        if (result.affectedRows === 0) return res.status(404).json({ error: 'Payment not found' });
        res.json({ message: 'Payment deleted' });
    });
});

function calculateBookingAmount(start_time, end_time, car_id) {
    const start = new Date(start_time);
    const end = new Date(end_time);
    const hours = Math.ceil((end - start) / (1000 * 60 * 60));

    const baseRate = 50;
    const carPremium = car_id * 10;

    return (baseRate + carPremium) * hours;
}

const PORT = 3000;
app.listen(PORT, () => console.log(`🚀 Enhanced Server running on port ${PORT}`));