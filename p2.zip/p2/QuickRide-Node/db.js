const mysql = require('mysql2');

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'quickride_db',
    charset: 'utf8mb4'
});

db.connect(err => {
    if (err) {
        console.error('❌ MySQL Connection Error:', err.message);
        console.log('💡 Troubleshooting:');
        console.log('   1. Make sure XAMPP MySQL is running');
        console.log('   2. Check if database "quickride_db" exists');
        console.log('   3. Verify MySQL credentials');
        // Do not exit the process so the server can still serve static assets and image listing
        // Application code should handle query errors when DB is unavailable.
    }
    console.log('✅ MySQL Connected to quickride_db...');
});

db.on('error', (err) => {
    console.error('❌ MySQL Database Error:', err);
    if (err.code === 'PROTOCOL_CONNECTION_LOST') {
        console.log('🔁 Reconnecting to database...');
    } else {
        throw err;
    }
});

module.exports = db;