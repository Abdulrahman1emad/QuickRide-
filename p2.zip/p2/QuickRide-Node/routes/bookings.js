const express = require('express');
const router = express.Router();
const db = require('../db');

router.get('/', (req, res) => {
    db.query('SELECT * FROM bookings', (err, results) => {
        if (err) return res.status(500).send(err);
        res.json(results);
    });
});

router.post("/", (req, res) => {
    const { customer_id, car_id, start_time, end_time, status } = req.body;
    const sql = "INSERT INTO bookings (customer_id, car_id, start_time, end_time, status) VALUES (?, ?, ?, ?, ?)";
    db.query(sql, [customer_id, car_id, start_time, end_time, status], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: "Booking added successfully!" });
    });
});


router.put('/:id', (req, res) => {
    const { id } = req.params;
    const { start_date, end_date, total_price } = req.body;
    const sql = 'UPDATE bookings SET start_date = ?, end_date = ?, total_price = ? WHERE booking_id = ?';
    db.query(sql, [start_date, end_date, total_price, id], (err, result) => {
        if (err) return res.status(500).send(err);
        res.json({ message: 'Booking updated successfully' });
    });
});

router.delete('/:id', (req, res) => {
    const { id } = req.params;
    db.query('DELETE FROM bookings WHERE booking_id = ?', [id], (err, result) => {
        if (err) return res.status(500).send(err);
        res.json({ message: 'Booking deleted successfully' });
    });
});

module.exports = router;
