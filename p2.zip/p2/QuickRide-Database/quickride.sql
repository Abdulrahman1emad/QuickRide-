CREATE DATABASE IF NOT EXISTS quickride_db;
USE quickride_db;