DROP DATABASE IF EXISTS quickride_db;
CREATE DATABASE quickride_db;
USE quickride_db;
CREATE TABLE IF NOT EXISTS customers (
  customer_id INT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(100) NOT NULL,
  email VARCHAR(100) UNIQUE NOT NULL,
  phone_number VARCHAR(20),
  password VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  loyalty_points INT DEFAULT 0,
  status ENUM('active', 'inactive') DEFAULT 'active'
);
CREATE TABLE IF NOT EXISTS cars (
  car_id INT AUTO_INCREMENT PRIMARY KEY,
  make VARCHAR(50) NOT NULL,
  model VARCHAR(50) NOT NULL,
  year INT NOT NULL,
  license_plate VARCHAR(20) UNIQUE NOT NULL,
  status ENUM('available', 'rented', 'maintenance') DEFAULT 'available',
  daily_rate DECIMAL(10, 2) DEFAULT 50.00,
  image_url VARCHAR(255),
  features TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS bookings (
  booking_id INT AUTO_INCREMENT PRIMARY KEY,
  customer_id INT,
  car_id INT,
  start_time DATETIME NOT NULL,
  end_time DATETIME NOT NULL,
  status ENUM('pending', 'confirmed', 'cancelled', 'completed') DEFAULT 'pending',
  total_amount DECIMAL(10, 2),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
  FOREIGN KEY (car_id) REFERENCES cars(car_id)
);
CREATE TABLE IF NOT EXISTS payments (
  payment_id INT AUTO_INCREMENT PRIMARY KEY,
  booking_id INT,
  amount DECIMAL(10, 2) NOT NULL,
  payment_method ENUM('credit_card', 'cash', 'paypal') DEFAULT 'credit_card',
  payment_date DATETIME DEFAULT CURRENT_TIMESTAMP,
  status ENUM('pending', 'completed', 'failed') DEFAULT 'completed',
  transaction_id VARCHAR(100),
  FOREIGN KEY (booking_id) REFERENCES bookings(booking_id)
);
CREATE TABLE IF NOT EXISTS admins (
  admin_id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  role ENUM('superadmin', 'staff') DEFAULT 'staff',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  last_login DATETIME
);
CREATE TABLE IF NOT EXISTS car_categories (
  category_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(50) NOT NULL,
  description TEXT,
  base_rate DECIMAL(10, 2) DEFAULT 50.00
);
INSERT INTO customers (
    full_name,
    email,
    phone_number,
    password,
    loyalty_points
  )
VALUES (
    'Ali Al Saud',
    'ali@example.com',
    '0551234567',
    'hashedpassword1',
    150
  ),
  (
    'Fatimah Al Fahad',
    'fatimah@example.com',
    '0557654321',
    'hashedpassword2',
    75
  ),
  (
    'Mohammed Al Zahrani',
    'mohammed@example.com',
    '0559876543',
    'hashedpassword3',
    200
  ),
  (
    'Layla Al Otaibi',
    'layla@example.com',
    '0552468101',
    'hashedpassword4',
    50
  ),
  (
    'Omar Al-Qahtani',
    'omar@example.com',
    '0551357913',
    'hashedpassword5',
    300
  );
INSERT INTO cars (
    make,
    model,
    year,
    license_plate,
    status,
    daily_rate,
    features
  )
VALUES (
    'Toyota',
    'Camry',
    2020,
    'XYZ1234',
    'available',
    80.00,
    'Automatic, AC, Bluetooth, Navigation'
  ),
  (
    'Honda',
    'Civic',
    2019,
    'ABC5678',
    'available',
    70.00,
    'Automatic, AC, Sunroof'
  ),
  (
    'Ford',
    'Mustang',
    2021,
    'DEF9012',
    'maintenance',
    120.00,
    'Automatic, Premium Sound, Sport Mode'
  ),
  (
    'BMW',
    'X5',
    2022,
    'GHI3456',
    'available',
    150.00,
    'Automatic, Leather Seats, Sunroof, Navigation'
  ),
  (
    'Mercedes',
    'C300',
    2021,
    'JKL7890',
    'available',
    130.00,
    'Automatic, Premium Package, Heated Seats'
  ),
  (
    'Tesla',
    'Model 3',
    2023,
    'MNO1234',
    'available',
    100.00,
    'Electric, Autopilot, Premium Interior'
  ),
  (
    'Audi',
    'A4',
    2022,
    'PQR5678',
    'rented',
    110.00,
    'Quattro, Leather, Tech Package'
  ),
  (
    'Hyundai',
    'Tucson',
    2021,
    'STU9012',
    'available',
    65.00,
    'SUV, Automatic, AC'
  );
INSERT INTO bookings (
    customer_id,
    car_id,
    start_time,
    end_time,
    status,
    total_amount
  )
VALUES (
    1,
    1,
    '2025-11-01 09:00:00',
    '2025-11-01 18:00:00',
    'completed',
    720.00
  ),
  (
    2,
    4,
    '2025-11-02 10:00:00',
    '2025-11-02 15:00:00',
    'confirmed',
    750.00
  ),
  (
    3,
    6,
    '2025-11-03 08:00:00',
    '2025-11-03 20:00:00',
    'cancelled',
    1200.00
  ),
  (
    4,
    2,
    '2025-11-04 09:00:00',
    '2025-11-04 17:00:00',
    'pending',
    560.00
  ),
  (
    5,
    5,
    '2025-11-05 11:00:00',
    '2025-11-05 16:00:00',
    'confirmed',
    650.00
  ),
  (
    1,
    3,
    '2025-11-06 14:00:00',
    '2025-11-06 18:00:00',
    'completed',
    480.00
  ),
  (
    2,
    8,
    '2025-11-07 08:00:00',
    '2025-11-07 20:00:00',
    'confirmed',
    780.00
  );
INSERT INTO payments (
    booking_id,
    amount,
    payment_method,
    payment_date,
    status
  )
VALUES (
    1,
    720.00,
    'credit_card',
    '2025-10-30 12:00:00',
    'completed'
  ),
  (
    2,
    750.00,
    'paypal',
    '2025-10-30 13:00:00',
    'completed'
  ),
  (
    3,
    1200.00,
    'credit_card',
    '2025-10-30 14:00:00',
    'failed'
  ),
  (
    4,
    560.00,
    'cash',
    '2025-10-30 15:00:00',
    'pending'
  ),
  (
    5,
    650.00,
    'credit_card',
    '2025-10-30 16:00:00',
    'completed'
  ),
  (
    6,
    480.00,
    'paypal',
    '2025-10-30 17:00:00',
    'completed'
  ),
  (
    7,
    780.00,
    'credit_card',
    '2025-10-30 18:00:00',
    'completed'
  );
INSERT INTO admins (username, password, role)
VALUES ('admin', 'admin123', 'superadmin'),
  ('staff1', 'staff123', 'staff'),
  ('staff2', 'staff456', 'staff');
INSERT INTO car_categories (name, description, base_rate)
VALUES (
    'Economy',
    'Fuel-efficient compact cars perfect for city driving',
    50.00
  ),
  (
    'Luxury',
    'Premium vehicles with advanced features and comfort',
    120.00
  ),
  (
    'SUV',
    'Spacious vehicles ideal for families and groups',
    80.00
  ),
  (
    'Sports',
    'High-performance cars for enthusiasts',
    150.00
  ),
  (
    'Electric',
    'Environmentally friendly electric vehicles',
    90.00
  );